#include "frame.h"

void menu();
void print_menu1();
void print_menu2();