#include "../headers/menu.h"

void main(){
    
    menu();
    
}