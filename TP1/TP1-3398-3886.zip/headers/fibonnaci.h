#include <stdio.h>

void fibonnaci(int* sequence, int n);
void printFibonnaci(int* sequence, int n);