#include "map.h"

void menu();
void printMenu1();
void remap(Data* data);
