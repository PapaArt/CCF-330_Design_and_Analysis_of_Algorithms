#include "../headers/fibonnaci.h"

int main() {
    int sequence[100];

    fibonnaci(sequence, 100);
	printFibonnaci(sequence, 100);

    return 0;
}